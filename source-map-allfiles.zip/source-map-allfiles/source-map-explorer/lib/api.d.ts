import type { Bundle, BundlesAndFileTokens, ExploreOptions, ExploreResult } from './types';
export declare function explore(bundlesAndFileTokens: BundlesAndFileTokens, options?: ExploreOptions): Promise<ExploreResult>;
export declare function getBundles(fileTokens: string[]): Bundle[];
export declare function getBundleName(bundle: Bundle): string;
