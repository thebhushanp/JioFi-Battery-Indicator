import type { Bundle, ColumnsRange, MappingRange, FileDataMap } from './types';
export declare function addCoverageRanges(bundles: Bundle[], coverageFilename?: string): Bundle[];
export declare function setCoveredSizes(line: string, files: FileDataMap, mappingRanges: MappingRange[], coveredRanges: ColumnsRange[]): FileDataMap;
export declare function getColorByPercent(percent: number): string;
