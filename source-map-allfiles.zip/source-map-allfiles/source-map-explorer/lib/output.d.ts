import type { ExploreBundleResult, ExploreOptions, ExploreResult } from './types';
export declare function formatOutput(results: ExploreBundleResult[], options: ExploreOptions): string | undefined;
export declare function saveOutputToFile(result: ExploreResult, options: ExploreOptions): void;
