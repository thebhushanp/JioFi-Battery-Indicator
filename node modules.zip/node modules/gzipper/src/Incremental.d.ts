import { Cache, IncrementalFileValue } from './interfaces';
import { Config } from './Config';
export declare class Incremental implements Cache {
    readonly cacheFolder: string;
    private readonly nativeFs;
    private readonly config;
    private filePaths;
    /**
     * Creates an instance of Incremental.
     */
    constructor(config: Config);
    /**
     * Read config (.gzipperconfig).
     */
    readConfig(): Promise<void>;
    /**
     * update config (.gzipperconfig).
     */
    updateConfig(): Promise<void>;
    /**
     * Create cache folder (.gzipper).
     */
    initCacheFolder(): Promise<void>;
    /**
     * Returns file incremental info and save checksum and options to `filePath` (if file is changed or newly created).
     */
    setFile(target: string, checksum: string, compressOptions: IncrementalFileValue['revisions'][number]['options']): {
        isChanged: boolean;
        fileId: string;
    };
    /**
     * Returns file checksum.
     */
    getFileChecksum(target: string): Promise<string>;
    /**
     * Purge cache folder.
     */
    cachePurge(): Promise<void>;
    /**
     * Returns cache size.
     */
    cacheSize(folderPath?: string, size?: number): Promise<number>;
}
