"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Incremental = void 0;
var fs_1 = __importDefault(require("fs"));
var crypto_1 = __importDefault(require("crypto"));
var path_1 = __importDefault(require("path"));
var util_1 = __importDefault(require("util"));
var uuid_1 = require("uuid");
var deep_equal_1 = __importDefault(require("deep-equal"));
var constants_1 = require("./constants");
var helpers_1 = require("./helpers");
var Incremental = /** @class */ (function () {
    /**
     * Creates an instance of Incremental.
     */
    function Incremental(config) {
        this.nativeFs = {
            exists: util_1.default.promisify(fs_1.default.exists),
            unlink: util_1.default.promisify(fs_1.default.unlink),
            readdir: util_1.default.promisify(fs_1.default.readdir),
            lstat: util_1.default.promisify(fs_1.default.lstat),
            rmdir: util_1.default.promisify(fs_1.default.rmdir),
        };
        this.filePaths = new Map();
        this.config = config;
        this.cacheFolder = path_1.default.resolve(process.cwd(), constants_1.CONFIG_FOLDER, constants_1.CACHE_FOLDER);
    }
    /**
     * Read config (.gzipperconfig).
     */
    Incremental.prototype.readConfig = function () {
        return __awaiter(this, void 0, void 0, function () {
            var response, data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.nativeFs.exists(this.config.configFile)];
                    case 1:
                        if (!_a.sent()) return [3 /*break*/, 3];
                        return [4 /*yield*/, helpers_1.Helpers.readFile(this.config.configFile)];
                    case 2:
                        response = _a.sent();
                        data = JSON.parse(response.toString());
                        if (data.incremental) {
                            this.filePaths = new Map(Object.entries(data.incremental.files));
                        }
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * update config (.gzipperconfig).
     */
    Incremental.prototype.updateConfig = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                this.config.setWritableContentProperty('incremental', {
                    files: helpers_1.Helpers.mapToJSON(this.filePaths),
                });
                return [2 /*return*/];
            });
        });
    };
    /**
     * Create cache folder (.gzipper).
     */
    Incremental.prototype.initCacheFolder = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.nativeFs.exists(this.cacheFolder)];
                    case 1:
                        if (!!(_a.sent())) return [3 /*break*/, 3];
                        return [4 /*yield*/, helpers_1.Helpers.createFolders(this.cacheFolder)];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Returns file incremental info and save checksum and options to `filePath` (if file is changed or newly created).
     */
    Incremental.prototype.setFile = function (target, checksum, compressOptions) {
        var filePath = this.filePaths.get(target);
        var selectedRevision = filePath === null || filePath === void 0 ? void 0 : filePath.revisions.find(function (revision) {
            return deep_equal_1.default(revision.options, compressOptions);
        });
        if (!filePath) {
            var fileId = uuid_1.v4();
            this.filePaths.set(target, {
                revisions: [
                    {
                        lastChecksum: checksum,
                        fileId: fileId,
                        date: new Date(),
                        options: compressOptions,
                    },
                ],
            });
            return {
                isChanged: true,
                fileId: fileId,
            };
        }
        if (!selectedRevision) {
            var fileId = uuid_1.v4();
            this.filePaths.set(target, {
                revisions: filePath.revisions.concat({
                    lastChecksum: checksum,
                    fileId: fileId,
                    date: new Date(),
                    options: compressOptions,
                }),
            });
            return {
                isChanged: true,
                fileId: fileId,
            };
        }
        if (selectedRevision.lastChecksum !== checksum) {
            this.filePaths.set(target, {
                revisions: filePath.revisions.map(function (revision) {
                    return revision.fileId === selectedRevision.fileId
                        ? __assign(__assign({}, revision), { date: new Date(), lastChecksum: checksum }) : revision;
                }),
            });
            return {
                isChanged: true,
                fileId: selectedRevision.fileId,
            };
        }
        return {
            isChanged: false,
            fileId: selectedRevision.fileId,
        };
    };
    /**
     * Returns file checksum.
     */
    Incremental.prototype.getFileChecksum = function (target) {
        return __awaiter(this, void 0, void 0, function () {
            var hash, stream;
            return __generator(this, function (_a) {
                hash = crypto_1.default.createHash('md5');
                stream = fs_1.default.createReadStream(target);
                return [2 /*return*/, new Promise(function (resolve, reject) {
                        stream.on('data', function (data) { return hash.update(data, 'utf8'); });
                        stream.on('end', function () { return resolve(hash.digest('hex')); });
                        stream.on('error', function (error) { return reject(error); });
                    })];
            });
        });
    };
    /**
     * Purge cache folder.
     */
    Incremental.prototype.cachePurge = function () {
        return __awaiter(this, void 0, void 0, function () {
            var recursiveRemove;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.nativeFs.exists(this.cacheFolder)];
                    case 1:
                        if (!(_a.sent())) {
                            throw new Error('No cache found.');
                        }
                        recursiveRemove = function (folderPath) {
                            if (folderPath === void 0) { folderPath = _this.cacheFolder; }
                            return __awaiter(_this, void 0, void 0, function () {
                                var files, files_1, files_1_1, file, filePath, isDirectory, e_1_1;
                                var e_1, _a;
                                return __generator(this, function (_b) {
                                    switch (_b.label) {
                                        case 0: return [4 /*yield*/, this.nativeFs.readdir(folderPath)];
                                        case 1:
                                            files = _b.sent();
                                            _b.label = 2;
                                        case 2:
                                            _b.trys.push([2, 10, 11, 12]);
                                            files_1 = __values(files), files_1_1 = files_1.next();
                                            _b.label = 3;
                                        case 3:
                                            if (!!files_1_1.done) return [3 /*break*/, 9];
                                            file = files_1_1.value;
                                            filePath = path_1.default.resolve(folderPath, file);
                                            return [4 /*yield*/, this.nativeFs.lstat(filePath)];
                                        case 4:
                                            isDirectory = (_b.sent()).isDirectory();
                                            if (!isDirectory) return [3 /*break*/, 6];
                                            return [4 /*yield*/, recursiveRemove(filePath)];
                                        case 5:
                                            _b.sent();
                                            return [3 /*break*/, 8];
                                        case 6: return [4 /*yield*/, this.nativeFs.unlink(filePath)];
                                        case 7:
                                            _b.sent();
                                            _b.label = 8;
                                        case 8:
                                            files_1_1 = files_1.next();
                                            return [3 /*break*/, 3];
                                        case 9: return [3 /*break*/, 12];
                                        case 10:
                                            e_1_1 = _b.sent();
                                            e_1 = { error: e_1_1 };
                                            return [3 /*break*/, 12];
                                        case 11:
                                            try {
                                                if (files_1_1 && !files_1_1.done && (_a = files_1.return)) _a.call(files_1);
                                            }
                                            finally { if (e_1) throw e_1.error; }
                                            return [7 /*endfinally*/];
                                        case 12: return [4 /*yield*/, this.nativeFs.rmdir(folderPath)];
                                        case 13:
                                            _b.sent();
                                            return [2 /*return*/];
                                    }
                                });
                            });
                        };
                        return [4 /*yield*/, recursiveRemove()];
                    case 2:
                        _a.sent();
                        this.config.deleteWritableContentProperty('incremental');
                        return [4 /*yield*/, this.config.writeConfig()];
                    case 3:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    /**
     * Returns cache size.
     */
    Incremental.prototype.cacheSize = function (folderPath, size) {
        if (folderPath === void 0) { folderPath = this.cacheFolder; }
        if (size === void 0) { size = 0; }
        return __awaiter(this, void 0, void 0, function () {
            var files, files_2, files_2_1, file, filePath, fileStat, _a, e_2_1;
            var e_2, _b;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, this.nativeFs.exists(this.cacheFolder)];
                    case 1:
                        if (!(_c.sent())) {
                            throw new Error('No cache found.');
                        }
                        return [4 /*yield*/, this.nativeFs.readdir(folderPath)];
                    case 2:
                        files = _c.sent();
                        if (!files.length) {
                            return [2 /*return*/, 0];
                        }
                        _c.label = 3;
                    case 3:
                        _c.trys.push([3, 10, 11, 12]);
                        files_2 = __values(files), files_2_1 = files_2.next();
                        _c.label = 4;
                    case 4:
                        if (!!files_2_1.done) return [3 /*break*/, 9];
                        file = files_2_1.value;
                        filePath = path_1.default.resolve(folderPath, file);
                        return [4 /*yield*/, this.nativeFs.lstat(filePath)];
                    case 5:
                        fileStat = _c.sent();
                        if (!fileStat.isDirectory()) return [3 /*break*/, 7];
                        _a = size;
                        return [4 /*yield*/, this.cacheSize(filePath, size)];
                    case 6:
                        size = _a + _c.sent();
                        return [3 /*break*/, 8];
                    case 7:
                        if (fileStat.isFile()) {
                            size += fileStat.size;
                        }
                        _c.label = 8;
                    case 8:
                        files_2_1 = files_2.next();
                        return [3 /*break*/, 4];
                    case 9: return [3 /*break*/, 12];
                    case 10:
                        e_2_1 = _c.sent();
                        e_2 = { error: e_2_1 };
                        return [3 /*break*/, 12];
                    case 11:
                        try {
                            if (files_2_1 && !files_2_1.done && (_b = files_2.return)) _b.call(files_2);
                        }
                        finally { if (e_2) throw e_2.error; }
                        return [7 /*endfinally*/];
                    case 12: return [2 /*return*/, size];
                }
            });
        });
    };
    return Incremental;
}());
exports.Incremental = Incremental;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiSW5jcmVtZW50YWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvSW5jcmVtZW50YWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDBDQUFvQjtBQUNwQixrREFBNEI7QUFDNUIsOENBQXdCO0FBQ3hCLDhDQUF3QjtBQUN4Qiw2QkFBMEI7QUFDMUIsMERBQW1DO0FBRW5DLHlDQUEwRDtBQUMxRCxxQ0FBb0M7QUFJcEM7SUFZRTs7T0FFRztJQUNILHFCQUFZLE1BQWM7UUFiVCxhQUFRLEdBQUc7WUFDMUIsTUFBTSxFQUFFLGNBQUksQ0FBQyxTQUFTLENBQUMsWUFBRSxDQUFDLE1BQU0sQ0FBQztZQUNqQyxNQUFNLEVBQUUsY0FBSSxDQUFDLFNBQVMsQ0FBQyxZQUFFLENBQUMsTUFBTSxDQUFDO1lBQ2pDLE9BQU8sRUFBRSxjQUFJLENBQUMsU0FBUyxDQUFDLFlBQUUsQ0FBQyxPQUFPLENBQUM7WUFDbkMsS0FBSyxFQUFFLGNBQUksQ0FBQyxTQUFTLENBQUMsWUFBRSxDQUFDLEtBQUssQ0FBQztZQUMvQixLQUFLLEVBQUUsY0FBSSxDQUFDLFNBQVMsQ0FBQyxZQUFFLENBQUMsS0FBSyxDQUFDO1NBQ2hDLENBQUM7UUFFTSxjQUFTLEdBQUcsSUFBSSxHQUFHLEVBQWdDLENBQUM7UUFNMUQsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDckIsSUFBSSxDQUFDLFdBQVcsR0FBRyxjQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSx5QkFBYSxFQUFFLHdCQUFZLENBQUMsQ0FBQztJQUM5RSxDQUFDO0lBRUQ7O09BRUc7SUFDRyxnQ0FBVSxHQUFoQjs7Ozs7NEJBQ00scUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBQTs7NkJBQWxELFNBQWtELEVBQWxELHdCQUFrRDt3QkFDbkMscUJBQU0saUJBQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBQTs7d0JBQXpELFFBQVEsR0FBRyxTQUE4Qzt3QkFDekQsSUFBSSxHQUFlLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7d0JBQ3pELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTs0QkFDcEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzt5QkFDbEU7Ozs7OztLQUVKO0lBRUQ7O09BRUc7SUFDRyxrQ0FBWSxHQUFsQjs7O2dCQUNFLElBQUksQ0FBQyxNQUFNLENBQUMsMEJBQTBCLENBQUMsYUFBYSxFQUFFO29CQUNwRCxLQUFLLEVBQUUsaUJBQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztpQkFDekMsQ0FBQyxDQUFDOzs7O0tBQ0o7SUFFRDs7T0FFRztJQUNHLHFDQUFlLEdBQXJCOzs7OzRCQUNRLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBQTs7NkJBQTlDLENBQUMsQ0FBQyxTQUE0QyxDQUFDLEVBQS9DLHdCQUErQzt3QkFDakQscUJBQU0saUJBQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFBOzt3QkFBN0MsU0FBNkMsQ0FBQzs7Ozs7O0tBRWpEO0lBRUQ7O09BRUc7SUFDSCw2QkFBTyxHQUFQLFVBQ0UsTUFBYyxFQUNkLFFBQWdCLEVBQ2hCLGVBQXFFO1FBS3JFLElBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVDLElBQU0sZ0JBQWdCLEdBQUcsUUFBUSxhQUFSLFFBQVEsdUJBQVIsUUFBUSxDQUFFLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBQyxRQUFRO1lBQ3pELE9BQUEsb0JBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQztRQUE1QyxDQUE0QyxDQUM3QyxDQUFDO1FBRUYsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLElBQU0sTUFBTSxHQUFHLFNBQUUsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRTtnQkFDekIsU0FBUyxFQUFFO29CQUNUO3dCQUNFLFlBQVksRUFBRSxRQUFRO3dCQUN0QixNQUFNLFFBQUE7d0JBQ04sSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO3dCQUNoQixPQUFPLEVBQUUsZUFBZTtxQkFDekI7aUJBQ0Y7YUFDRixDQUFDLENBQUM7WUFFSCxPQUFPO2dCQUNMLFNBQVMsRUFBRSxJQUFJO2dCQUNmLE1BQU0sUUFBQTthQUNQLENBQUM7U0FDSDtRQUVELElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtZQUNyQixJQUFNLE1BQU0sR0FBRyxTQUFFLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUU7Z0JBQ3pCLFNBQVMsRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztvQkFDbkMsWUFBWSxFQUFFLFFBQVE7b0JBQ3RCLE1BQU0sUUFBQTtvQkFDTixJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUU7b0JBQ2hCLE9BQU8sRUFBRSxlQUFlO2lCQUN6QixDQUFDO2FBQ0gsQ0FBQyxDQUFDO1lBRUgsT0FBTztnQkFDTCxTQUFTLEVBQUUsSUFBSTtnQkFDZixNQUFNLFFBQUE7YUFDUCxDQUFDO1NBQ0g7UUFFRCxJQUFJLGdCQUFnQixDQUFDLFlBQVksS0FBSyxRQUFRLEVBQUU7WUFDOUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFO2dCQUN6QixTQUFTLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBQyxRQUFRO29CQUN6QyxPQUFPLFFBQVEsQ0FBQyxNQUFNLEtBQUssZ0JBQWdCLENBQUMsTUFBTTt3QkFDaEQsQ0FBQyx1QkFBTSxRQUFRLEtBQUUsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLEVBQUUsWUFBWSxFQUFFLFFBQVEsSUFDekQsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQkFDZixDQUFDLENBQUM7YUFDSCxDQUFDLENBQUM7WUFFSCxPQUFPO2dCQUNMLFNBQVMsRUFBRSxJQUFJO2dCQUNmLE1BQU0sRUFBRSxnQkFBZ0IsQ0FBQyxNQUFNO2FBQ2hDLENBQUM7U0FDSDtRQUVELE9BQU87WUFDTCxTQUFTLEVBQUUsS0FBSztZQUNoQixNQUFNLEVBQUUsZ0JBQWdCLENBQUMsTUFBTTtTQUNoQyxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0cscUNBQWUsR0FBckIsVUFBc0IsTUFBYzs7OztnQkFDNUIsSUFBSSxHQUFHLGdCQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoQyxNQUFNLEdBQUcsWUFBRSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUUzQyxzQkFBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNO3dCQUNqQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFDLElBQVksSUFBSyxPQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxFQUF6QixDQUF5QixDQUFDLENBQUM7d0JBQy9ELE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSyxFQUFFLGNBQU0sT0FBQSxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUEzQixDQUEyQixDQUFDLENBQUM7d0JBQ3BELE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUMsS0FBSyxJQUFLLE9BQUEsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFiLENBQWEsQ0FBQyxDQUFDO29CQUMvQyxDQUFDLENBQUMsRUFBQzs7O0tBQ0o7SUFFRDs7T0FFRztJQUNHLGdDQUFVLEdBQWhCOzs7Ozs7NEJBQ1EscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFBOzt3QkFBbEQsSUFBSSxDQUFDLENBQUMsU0FBNEMsQ0FBQyxFQUFFOzRCQUNuRCxNQUFNLElBQUksS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUM7eUJBQ3BDO3dCQUVLLGVBQWUsR0FBRyxVQUN0QixVQUE2Qjs0QkFBN0IsMkJBQUEsRUFBQSxhQUFhLEtBQUksQ0FBQyxXQUFXOzs7Ozs7Z0RBRWYscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUE7OzRDQUEvQyxLQUFLLEdBQUcsU0FBdUM7Ozs7NENBRWxDLFVBQUEsU0FBQSxLQUFLLENBQUE7Ozs7NENBQWIsSUFBSTs0Q0FDUCxRQUFRLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7NENBQzNCLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFBOzs0Q0FBbEQsV0FBVyxHQUFHLENBQUMsU0FBbUMsQ0FBQyxDQUFDLFdBQVcsRUFBRTtpREFFbkUsV0FBVyxFQUFYLHdCQUFXOzRDQUNiLHFCQUFNLGVBQWUsQ0FBQyxRQUFRLENBQUMsRUFBQTs7NENBQS9CLFNBQStCLENBQUM7O2dEQUVoQyxxQkFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsRUFBQTs7NENBQXBDLFNBQW9DLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7aURBSXpDLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFBOzs0Q0FBckMsU0FBcUMsQ0FBQzs7Ozs7eUJBQ3ZDLENBQUM7d0JBRUYscUJBQU0sZUFBZSxFQUFFLEVBQUE7O3dCQUF2QixTQUF1QixDQUFDO3dCQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsQ0FBQyxDQUFDO3dCQUN6RCxxQkFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFBOzt3QkFBL0IsU0FBK0IsQ0FBQzs7Ozs7S0FDakM7SUFFRDs7T0FFRztJQUNHLCtCQUFTLEdBQWYsVUFBZ0IsVUFBNkIsRUFBRSxJQUFRO1FBQXZDLDJCQUFBLEVBQUEsYUFBYSxJQUFJLENBQUMsV0FBVztRQUFFLHFCQUFBLEVBQUEsUUFBUTs7Ozs7OzRCQUMvQyxxQkFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUE7O3dCQUFsRCxJQUFJLENBQUMsQ0FBQyxTQUE0QyxDQUFDLEVBQUU7NEJBQ25ELE1BQU0sSUFBSSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt5QkFDcEM7d0JBRWEscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEVBQUE7O3dCQUEvQyxLQUFLLEdBQUcsU0FBdUM7d0JBRXJELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFOzRCQUNqQixzQkFBTyxDQUFDLEVBQUM7eUJBQ1Y7Ozs7d0JBRWtCLFVBQUEsU0FBQSxLQUFLLENBQUE7Ozs7d0JBQWIsSUFBSTt3QkFDUCxRQUFRLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQy9CLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFBOzt3QkFBOUMsUUFBUSxHQUFHLFNBQW1DOzZCQUVoRCxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQXRCLHdCQUFzQjt3QkFDeEIsS0FBQSxJQUFJLENBQUE7d0JBQUkscUJBQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLEVBQUE7O3dCQUE1QyxJQUFJLEdBQUosS0FBUSxTQUFvQyxDQUFDOzs7d0JBQ3hDLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFOzRCQUM1QixJQUFJLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQzt5QkFDdkI7Ozs7Ozs7Ozs7Ozs7Ozs7NkJBRUgsc0JBQU8sSUFBSSxFQUFDOzs7O0tBQ2I7SUFDSCxrQkFBQztBQUFELENBQUMsQUFwTUQsSUFvTUM7QUFwTVksa0NBQVcifQ==