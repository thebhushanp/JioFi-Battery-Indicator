import { FileConfig } from './interfaces';
export declare class Config {
    readonly configFile: string;
    private readonly nativeFs;
    private readonly writableContent;
    /**
     * Creates an instance of Config.
     */
    constructor();
    /**
     * set additional data for property to config file (.gzipperconfig).
     */
    setWritableContentProperty<T extends keyof FileConfig, K extends FileConfig[T]>(field: T, content: K): void;
    /**
     * delete property from config file (.gzipperconfig).
     */
    deleteWritableContentProperty<T extends keyof FileConfig>(field: T): void;
    /**
     * Init or update config (.gzipperconfig).
     */
    writeConfig(): Promise<void>;
}
