"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Compress = void 0;
var fs_1 = __importDefault(require("fs"));
var path_1 = __importDefault(require("path"));
var util_1 = __importDefault(require("util"));
var uuid_1 = require("uuid");
var stream_1 = __importDefault(require("stream"));
var helpers_1 = require("./helpers");
var Logger_1 = require("./logger/Logger");
var Brotli_1 = require("./compressions/Brotli");
var Gzip_1 = require("./compressions/Gzip");
var constants_1 = require("./constants");
var Deflate_1 = require("./compressions/Deflate");
var Incremental_1 = require("./Incremental");
var Config_1 = require("./Config");
var LogLevel_enum_1 = require("./logger/LogLevel.enum");
/**
 * Compressing files.
 */
var Compress = /** @class */ (function () {
    /**
     * Creates an instance of Compress.
     */
    function Compress(target, outputPath, options) {
        if (options === void 0) { options = {}; }
        this.nativeFs = {
            lstat: util_1.default.promisify(fs_1.default.lstat),
            readdir: util_1.default.promisify(fs_1.default.readdir),
            exists: util_1.default.promisify(fs_1.default.exists),
            unlink: util_1.default.promisify(fs_1.default.unlink),
        };
        this.nativeStream = {
            pipeline: util_1.default.promisify(stream_1.default.pipeline),
        };
        this.logger = new Logger_1.Logger(options.verbose);
        this.config = new Config_1.Config();
        if (!target) {
            var message = constants_1.NO_PATH_MESSAGE;
            this.logger.log(message, LogLevel_enum_1.LogLevel.ERROR);
            throw new Error(message);
        }
        if (outputPath) {
            this.outputPath = path_1.default.resolve(process.cwd(), outputPath);
        }
        if (options.incremental) {
            this.incremental = new Incremental_1.Incremental(this.config);
        }
        this.target = path_1.default.resolve(process.cwd(), target);
        this.options = options;
        this.compressionInstance = this.getCompressionInstance();
        this.createCompression = this.compressionInstance.getCompression();
    }
    /**
     * Start compressing files.
     */
    Compress.prototype.run = function () {
        return __awaiter(this, void 0, void 0, function () {
            var files, hrtime, hrtimeStart, error_1, filesCount;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 10, , 11]);
                        if (!this.outputPath) return [3 /*break*/, 2];
                        return [4 /*yield*/, helpers_1.Helpers.createFolders(this.outputPath)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2:
                        if (!this.options.incremental) return [3 /*break*/, 5];
                        this.logger.log(constants_1.INCREMENTAL_ENABLE_MESSAGE, LogLevel_enum_1.LogLevel.INFO);
                        return [4 /*yield*/, this.incremental.initCacheFolder()];
                    case 3:
                        _a.sent();
                        return [4 /*yield*/, this.incremental.readConfig()];
                    case 4:
                        _a.sent();
                        _a.label = 5;
                    case 5:
                        this.compressionLog();
                        hrtimeStart = process.hrtime();
                        return [4 /*yield*/, this.compileFolderRecursively(this.target)];
                    case 6:
                        files = _a.sent();
                        hrtime = process.hrtime(hrtimeStart);
                        if (!this.options.incremental) return [3 /*break*/, 9];
                        return [4 /*yield*/, this.incremental.updateConfig()];
                    case 7:
                        _a.sent();
                        return [4 /*yield*/, this.config.writeConfig()];
                    case 8:
                        _a.sent();
                        _a.label = 9;
                    case 9: return [3 /*break*/, 11];
                    case 10:
                        error_1 = _a.sent();
                        this.logger.log(error_1, LogLevel_enum_1.LogLevel.ERROR);
                        throw new Error(error_1.message);
                    case 11:
                        filesCount = files.length;
                        if (filesCount) {
                            this.logger.log(filesCount + " " + (filesCount > 1 ? 'files have' : 'file has') + " been compressed. (" + helpers_1.Helpers.readableHrtime(hrtime) + ")", LogLevel_enum_1.LogLevel.SUCCESS);
                        }
                        else {
                            this.logger.log(constants_1.NO_FILES_MESSAGE, LogLevel_enum_1.LogLevel.WARNING);
                        }
                        return [2 /*return*/, files];
                }
            });
        });
    };
    /**
     * Return compression instance.
     */
    Compress.prototype.getCompressionInstance = function () {
        if (this.options.brotli) {
            return new Brotli_1.BrotliCompression(this.options, this.logger);
        }
        else if (this.options.deflate) {
            return new Deflate_1.DeflateCompression(this.options, this.logger);
        }
        else {
            return new Gzip_1.GzipCompression(this.options, this.logger);
        }
    };
    /**
     * Compile files in folder recursively.
     */
    Compress.prototype.compileFolderRecursively = function (target) {
        return __awaiter(this, void 0, void 0, function () {
            var compressedFiles, isFileTarget, filesList, targetParsed, filesList_1, filesList_1_1, file, filePath, fileStat, _a, _b, _c, hrtimeStart, fileInfo, hrTimeEnd, e_1_1, error_2;
            var e_1, _d;
            return __generator(this, function (_e) {
                switch (_e.label) {
                    case 0:
                        _e.trys.push([0, 15, , 16]);
                        compressedFiles = [];
                        return [4 /*yield*/, this.nativeFs.lstat(target)];
                    case 1:
                        isFileTarget = (_e.sent()).isFile();
                        filesList = void 0;
                        if (!isFileTarget) return [3 /*break*/, 2];
                        targetParsed = path_1.default.parse(target);
                        target = targetParsed.dir;
                        filesList = [targetParsed.base];
                        return [3 /*break*/, 4];
                    case 2: return [4 /*yield*/, this.nativeFs.readdir(target)];
                    case 3:
                        filesList = _e.sent();
                        _e.label = 4;
                    case 4:
                        _e.trys.push([4, 12, 13, 14]);
                        filesList_1 = __values(filesList), filesList_1_1 = filesList_1.next();
                        _e.label = 5;
                    case 5:
                        if (!!filesList_1_1.done) return [3 /*break*/, 11];
                        file = filesList_1_1.value;
                        filePath = path_1.default.resolve(target, file);
                        return [4 /*yield*/, this.nativeFs.lstat(filePath)];
                    case 6:
                        fileStat = _e.sent();
                        if (!fileStat.isDirectory()) return [3 /*break*/, 8];
                        _b = (_a = compressedFiles.push).apply;
                        _c = [compressedFiles];
                        return [4 /*yield*/, this.compileFolderRecursively(filePath)];
                    case 7:
                        _b.apply(_a, _c.concat([__spread.apply(void 0, [(_e.sent())])]));
                        return [3 /*break*/, 10];
                    case 8:
                        if (!(fileStat.isFile() &&
                            this.isValidFileExtensions(path_1.default.extname(filePath).slice(1)))) return [3 /*break*/, 10];
                        if (fileStat.size < this.options.threshold) {
                            return [3 /*break*/, 10];
                        }
                        hrtimeStart = process.hrtime();
                        return [4 /*yield*/, this.compressFile(file, target, this.outputPath)];
                    case 9:
                        fileInfo = _e.sent();
                        if (!fileInfo.removeCompiled) {
                            compressedFiles.push(filePath);
                        }
                        if (this.options.verbose) {
                            hrTimeEnd = process.hrtime(hrtimeStart);
                            this.logger.log(this.getCompressedFileMsg(file, fileInfo, hrTimeEnd));
                        }
                        _e.label = 10;
                    case 10:
                        filesList_1_1 = filesList_1.next();
                        return [3 /*break*/, 5];
                    case 11: return [3 /*break*/, 14];
                    case 12:
                        e_1_1 = _e.sent();
                        e_1 = { error: e_1_1 };
                        return [3 /*break*/, 14];
                    case 13:
                        try {
                            if (filesList_1_1 && !filesList_1_1.done && (_d = filesList_1.return)) _d.call(filesList_1);
                        }
                        finally { if (e_1) throw e_1.error; }
                        return [7 /*endfinally*/];
                    case 14: return [2 /*return*/, compressedFiles];
                    case 15:
                        error_2 = _e.sent();
                        throw error_2;
                    case 16: return [2 /*return*/];
                }
            });
        });
    };
    /**
     * File compression.
     */
    Compress.prototype.compressFile = function (filename, target, outputDir) {
        return __awaiter(this, void 0, void 0, function () {
            var isCached, inputPath, isFileTarget, outputPath, checksum, _a, isChanged, fileId, cachedFile, beforeSize, afterSize, removeCompiled;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        isCached = false;
                        inputPath = path_1.default.join(target, filename);
                        if (!outputDir) return [3 /*break*/, 3];
                        return [4 /*yield*/, this.nativeFs.lstat(this.target)];
                    case 1:
                        isFileTarget = (_b.sent()).isFile();
                        target = isFileTarget
                            ? outputDir
                            : path_1.default.join(outputDir, path_1.default.relative(this.target, target));
                        return [4 /*yield*/, helpers_1.Helpers.createFolders(target)];
                    case 2:
                        _b.sent();
                        _b.label = 3;
                    case 3:
                        outputPath = this.getOutputPath(target, filename);
                        if (!this.options.incremental) return [3 /*break*/, 11];
                        return [4 /*yield*/, this.incremental.getFileChecksum(inputPath)];
                    case 4:
                        checksum = _b.sent();
                        return [4 /*yield*/, this.incremental.setFile(inputPath, checksum, this.compressionInstance.compressionOptions)];
                    case 5:
                        _a = _b.sent(), isChanged = _a.isChanged, fileId = _a.fileId;
                        cachedFile = path_1.default.resolve(this.incremental.cacheFolder, fileId);
                        if (!isChanged) return [3 /*break*/, 8];
                        return [4 /*yield*/, this.nativeStream.pipeline(fs_1.default.createReadStream(inputPath), this.createCompression(), fs_1.default.createWriteStream(outputPath))];
                    case 6:
                        _b.sent();
                        return [4 /*yield*/, this.nativeStream.pipeline(fs_1.default.createReadStream(outputPath), fs_1.default.createWriteStream(cachedFile))];
                    case 7:
                        _b.sent();
                        return [3 /*break*/, 10];
                    case 8: return [4 /*yield*/, this.nativeStream.pipeline(fs_1.default.createReadStream(cachedFile), fs_1.default.createWriteStream(outputPath))];
                    case 9:
                        _b.sent();
                        isCached = true;
                        _b.label = 10;
                    case 10: return [3 /*break*/, 13];
                    case 11: return [4 /*yield*/, this.nativeStream.pipeline(fs_1.default.createReadStream(inputPath), this.createCompression(), fs_1.default.createWriteStream(outputPath))];
                    case 12:
                        _b.sent();
                        _b.label = 13;
                    case 13:
                        if (!(this.options.verbose || this.options.removeLarger)) return [3 /*break*/, 18];
                        return [4 /*yield*/, this.nativeFs.lstat(inputPath)];
                    case 14:
                        beforeSize = (_b.sent()).size;
                        return [4 /*yield*/, this.nativeFs.lstat(outputPath)];
                    case 15:
                        afterSize = (_b.sent()).size;
                        removeCompiled = this.options.removeLarger && beforeSize < afterSize;
                        if (!removeCompiled) return [3 /*break*/, 17];
                        return [4 /*yield*/, this.nativeFs.unlink(outputPath)];
                    case 16:
                        _b.sent();
                        _b.label = 17;
                    case 17: return [2 /*return*/, { beforeSize: beforeSize, afterSize: afterSize, isCached: isCached, removeCompiled: removeCompiled }];
                    case 18: return [2 /*return*/, { isCached: isCached }];
                }
            });
        });
    };
    /**
     * Show message with compression params.
     */
    Compress.prototype.compressionLog = function () {
        var options = this.compressionInstance.readableOptions();
        this.logger.log("Compression " + options, LogLevel_enum_1.LogLevel.INFO);
        if (!this.options.outputFileFormat) {
            this.logger.log(constants_1.DEFAULT_OUTPUT_FORMAT_MESSAGE, LogLevel_enum_1.LogLevel.INFO);
        }
    };
    /**
     * Get output path which is based on [outputFileFormat].
     */
    Compress.prototype.getOutputPath = function (target, file) {
        var artifactsMap = new Map([
            ['[filename]', path_1.default.parse(file).name],
            ['[ext]', path_1.default.extname(file).slice(1)],
            ['[compressExt]', this.compressionInstance.ext],
        ]);
        var filename = artifactsMap.get('[filename]') + "." + artifactsMap.get('[ext]') + "." + artifactsMap.get('[compressExt]');
        if (this.options.outputFileFormat) {
            artifactsMap.set('[hash]', null);
            filename = this.options.outputFileFormat.replace(constants_1.OUTPUT_FILE_FORMAT_REGEXP, function (artifact) {
                if (artifactsMap.has(artifact)) {
                    // Need to generate hash only if we have appropriate param
                    if (artifact === '[hash]') {
                        artifactsMap.set('[hash]', uuid_1.v4());
                    }
                    return artifactsMap.get(artifact);
                }
                else {
                    return artifact;
                }
            });
        }
        return "" + path_1.default.join(target, filename);
    };
    /**
     * Returns if the file extension is valid.
     */
    Compress.prototype.isValidFileExtensions = function (ext) {
        var excludeExtensions = this.options.exclude;
        var includeExtensions = this.options.include;
        if (includeExtensions && includeExtensions.length) {
            return includeExtensions.includes(ext);
        }
        if (excludeExtensions && excludeExtensions.length) {
            return !excludeExtensions.includes(ext);
        }
        return true;
    };
    /**
     * Returns information message about compressed file (size, time, cache, etc.)
     */
    Compress.prototype.getCompressedFileMsg = function (file, fileInfo, hrtime) {
        var getSize = helpers_1.Helpers.readableSize(fileInfo.beforeSize) + " -> " + helpers_1.Helpers.readableSize(fileInfo.afterSize);
        return fileInfo.isCached
            ? file + " has been retrieved from the cache " + getSize + " (" + helpers_1.Helpers.readableHrtime(hrtime) + ")"
            : "File " + file + " has been compressed " + getSize + " (" + helpers_1.Helpers.readableHrtime(hrtime) + ")";
    };
    return Compress;
}());
exports.Compress = Compress;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcHJlc3MuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvQ29tcHJlc3MudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDBDQUFvQjtBQUNwQiw4Q0FBd0I7QUFDeEIsOENBQXdCO0FBQ3hCLDZCQUEwQjtBQUMxQixrREFBNEI7QUFFNUIscUNBQW9DO0FBQ3BDLDBDQUF5QztBQUN6QyxnREFBMEQ7QUFDMUQsNENBQXNEO0FBQ3RELHlDQU1xQjtBQUVyQixrREFBNEQ7QUFDNUQsNkNBQTRDO0FBQzVDLG1DQUFrQztBQUNsQyx3REFBa0Q7QUFFbEQ7O0dBRUc7QUFDSDtJQXdCRTs7T0FFRztJQUNILGtCQUNFLE1BQWMsRUFDZCxVQUEwQixFQUMxQixPQUFzQztRQUF0Qyx3QkFBQSxFQUFBLFVBQTJCLEVBQVc7UUE3QnZCLGFBQVEsR0FBRztZQUMxQixLQUFLLEVBQUUsY0FBSSxDQUFDLFNBQVMsQ0FBQyxZQUFFLENBQUMsS0FBSyxDQUFDO1lBQy9CLE9BQU8sRUFBRSxjQUFJLENBQUMsU0FBUyxDQUFDLFlBQUUsQ0FBQyxPQUFPLENBQUM7WUFDbkMsTUFBTSxFQUFFLGNBQUksQ0FBQyxTQUFTLENBQUMsWUFBRSxDQUFDLE1BQU0sQ0FBQztZQUNqQyxNQUFNLEVBQUUsY0FBSSxDQUFDLFNBQVMsQ0FBQyxZQUFFLENBQUMsTUFBTSxDQUFDO1NBQ2xDLENBQUM7UUFDZSxpQkFBWSxHQUFHO1lBQzlCLFFBQVEsRUFBRSxjQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFNLENBQUMsUUFBUSxDQUFDO1NBQzFDLENBQUM7UUF1QkEsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLGVBQU0sQ0FBQyxPQUFPLENBQUMsT0FBa0IsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxlQUFNLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsTUFBTSxFQUFFO1lBQ1gsSUFBTSxPQUFPLEdBQUcsMkJBQWUsQ0FBQztZQUNoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsd0JBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QyxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzFCO1FBQ0QsSUFBSSxVQUFVLEVBQUU7WUFDZCxJQUFJLENBQUMsVUFBVSxHQUFHLGNBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1NBQzNEO1FBQ0QsSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSx5QkFBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUNqRDtRQUNELElBQUksQ0FBQyxNQUFNLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDdkIsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3pELElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDckUsQ0FBQztJQUVEOztPQUVHO0lBQ0csc0JBQUcsR0FBVDs7Ozs7Ozs2QkFJUSxJQUFJLENBQUMsVUFBVSxFQUFmLHdCQUFlO3dCQUNqQixxQkFBTSxpQkFBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUE7O3dCQUE1QyxTQUE0QyxDQUFDOzs7NkJBRTNDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUF4Qix3QkFBd0I7d0JBQzFCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHNDQUEwQixFQUFFLHdCQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQzNELHFCQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLEVBQUE7O3dCQUF4QyxTQUF3QyxDQUFDO3dCQUN6QyxxQkFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxFQUFBOzt3QkFBbkMsU0FBbUMsQ0FBQzs7O3dCQUV0QyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7d0JBQ2hCLFdBQVcsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7d0JBQzdCLHFCQUFNLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUE7O3dCQUF4RCxLQUFLLEdBQUcsU0FBZ0QsQ0FBQzt3QkFDekQsTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7NkJBQ2pDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUF4Qix3QkFBd0I7d0JBQzFCLHFCQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLEVBQUE7O3dCQUFyQyxTQUFxQyxDQUFDO3dCQUN0QyxxQkFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsRUFBRSxFQUFBOzt3QkFBL0IsU0FBK0IsQ0FBQzs7Ozs7d0JBR2xDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQUssRUFBRSx3QkFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUN2QyxNQUFNLElBQUksS0FBSyxDQUFDLE9BQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzs7d0JBRzNCLFVBQVUsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO3dCQUNoQyxJQUFJLFVBQVUsRUFBRTs0QkFDZCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FDVixVQUFVLFVBQ1gsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxVQUFVLDRCQUN0QixpQkFBTyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsTUFBRyxFQUN2RCx3QkFBUSxDQUFDLE9BQU8sQ0FDakIsQ0FBQzt5QkFDSDs2QkFBTTs0QkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyw0QkFBZ0IsRUFBRSx3QkFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO3lCQUNyRDt3QkFFRCxzQkFBTyxLQUFLLEVBQUM7Ozs7S0FDZDtJQUVEOztPQUVHO0lBQ0sseUNBQXNCLEdBQTlCO1FBSUUsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtZQUN2QixPQUFPLElBQUksMEJBQWlCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDekQ7YUFBTSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFO1lBQy9CLE9BQU8sSUFBSSw0QkFBa0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztTQUMxRDthQUFNO1lBQ0wsT0FBTyxJQUFJLHNCQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDdkQ7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDVywyQ0FBd0IsR0FBdEMsVUFBdUMsTUFBYzs7Ozs7Ozs7d0JBRTNDLGVBQWUsR0FBYSxFQUFFLENBQUM7d0JBQ2YscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUE7O3dCQUFqRCxZQUFZLEdBQUcsQ0FBQyxTQUFpQyxDQUFDLENBQUMsTUFBTSxFQUFFO3dCQUM3RCxTQUFTLFNBQVUsQ0FBQzs2QkFFcEIsWUFBWSxFQUFaLHdCQUFZO3dCQUNSLFlBQVksR0FBRyxjQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3dCQUN4QyxNQUFNLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQzt3QkFDMUIsU0FBUyxHQUFHLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDOzs0QkFFcEIscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUE7O3dCQUEvQyxTQUFTLEdBQUcsU0FBbUMsQ0FBQzs7Ozt3QkFHL0IsY0FBQSxTQUFBLFNBQVMsQ0FBQTs7Ozt3QkFBakIsSUFBSTt3QkFDUCxRQUFRLEdBQUcsY0FBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7d0JBQzNCLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFBOzt3QkFBOUMsUUFBUSxHQUFHLFNBQW1DOzZCQUVoRCxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQXRCLHdCQUFzQjs2QkFDeEIsQ0FBQSxLQUFBLGVBQWUsQ0FBQyxJQUFJLENBQUE7OEJBQXBCLGVBQWU7d0JBQ1QscUJBQU0sSUFBSSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxFQUFBOzt3QkFEbkQsZ0RBQ0ssQ0FBQyxTQUE2QyxDQUFDLE1BQ2xEOzs7NkJBRUYsQ0FBQSxRQUFRLENBQUMsTUFBTSxFQUFFOzRCQUNqQixJQUFJLENBQUMscUJBQXFCLENBQUMsY0FBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQSxFQUQzRCx5QkFDMkQ7d0JBRTNELElBQUksUUFBUSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRTs0QkFDMUMseUJBQVM7eUJBQ1Y7d0JBRUssV0FBVyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQzt3QkFDcEIscUJBQU0sSUFBSSxDQUFDLFlBQVksQ0FDdEMsSUFBSSxFQUNKLE1BQU0sRUFDTixJQUFJLENBQUMsVUFBVSxDQUNoQixFQUFBOzt3QkFKSyxRQUFRLEdBQUcsU0FJaEI7d0JBRUQsSUFBSSxDQUFFLFFBQTJCLENBQUMsY0FBYyxFQUFFOzRCQUNoRCxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUNoQzt3QkFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFOzRCQUNsQixTQUFTLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzs0QkFDOUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQ2IsSUFBSSxDQUFDLG9CQUFvQixDQUN2QixJQUFJLEVBQ0osUUFBMEIsRUFDMUIsU0FBUyxDQUNWLENBQ0YsQ0FBQzt5QkFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs2QkFHTCxzQkFBTyxlQUFlLEVBQUM7Ozt3QkFFdkIsTUFBTSxPQUFLLENBQUM7Ozs7O0tBRWY7SUFFRDs7T0FFRztJQUNXLCtCQUFZLEdBQTFCLFVBQ0UsUUFBZ0IsRUFDaEIsTUFBYyxFQUNkLFNBQTZCOzs7Ozs7d0JBRXpCLFFBQVEsR0FBRyxLQUFLLENBQUM7d0JBQ2YsU0FBUyxHQUFHLGNBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDOzZCQUMxQyxTQUFTLEVBQVQsd0JBQVM7d0JBQ1cscUJBQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFBOzt3QkFBdEQsWUFBWSxHQUFHLENBQUMsU0FBc0MsQ0FBQyxDQUFDLE1BQU0sRUFBRTt3QkFDdEUsTUFBTSxHQUFHLFlBQVk7NEJBQ25CLENBQUMsQ0FBQyxTQUFTOzRCQUNYLENBQUMsQ0FBQyxjQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxjQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQzt3QkFDN0QscUJBQU0saUJBQU8sQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEVBQUE7O3dCQUFuQyxTQUFtQyxDQUFDOzs7d0JBRWhDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQzs2QkFFcEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQXhCLHlCQUF3Qjt3QkFDVCxxQkFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsRUFBQTs7d0JBQTVELFFBQVEsR0FBRyxTQUFpRDt3QkFDcEMscUJBQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQzFELFNBQVMsRUFDVCxRQUFRLEVBQ1IsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtCQUFrQixDQUM1QyxFQUFBOzt3QkFKSyxLQUF3QixTQUk3QixFQUpPLFNBQVMsZUFBQSxFQUFFLE1BQU0sWUFBQTt3QkFNbkIsVUFBVSxHQUFHLGNBQUksQ0FBQyxPQUFPLENBQzdCLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUM1QixNQUFnQixDQUNqQixDQUFDOzZCQUVFLFNBQVMsRUFBVCx3QkFBUzt3QkFDWCxxQkFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FDOUIsWUFBRSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxFQUM5QixJQUFJLENBQUMsaUJBQWlCLEVBQUUsRUFDeEIsWUFBRSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUNqQyxFQUFBOzt3QkFKRCxTQUlDLENBQUM7d0JBRUYscUJBQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQzlCLFlBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsRUFDL0IsWUFBRSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxDQUNqQyxFQUFBOzt3QkFIRCxTQUdDLENBQUM7OzRCQUVGLHFCQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUM5QixZQUFFLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLEVBQy9CLFlBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FDakMsRUFBQTs7d0JBSEQsU0FHQyxDQUFDO3dCQUNGLFFBQVEsR0FBRyxJQUFJLENBQUM7Ozs2QkFHbEIscUJBQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQzlCLFlBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsRUFDOUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQ3hCLFlBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FDakMsRUFBQTs7d0JBSkQsU0FJQyxDQUFDOzs7NkJBR0EsQ0FBQSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQSxFQUFqRCx5QkFBaUQ7d0JBQy9CLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxFQUFBOzt3QkFBbEQsVUFBVSxHQUFHLENBQUMsU0FBb0MsQ0FBQyxDQUFDLElBQUk7d0JBQzNDLHFCQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFBOzt3QkFBbEQsU0FBUyxHQUFHLENBQUMsU0FBcUMsQ0FBQyxDQUFDLElBQUk7d0JBRXhELGNBQWMsR0FDbEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksVUFBVSxHQUFHLFNBQVMsQ0FBQzs2QkFDbEQsY0FBYyxFQUFkLHlCQUFjO3dCQUNoQixxQkFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBQTs7d0JBQXRDLFNBQXNDLENBQUM7OzZCQUV6QyxzQkFBTyxFQUFFLFVBQVUsWUFBQSxFQUFFLFNBQVMsV0FBQSxFQUFFLFFBQVEsVUFBQSxFQUFFLGNBQWMsZ0JBQUEsRUFBRSxFQUFDOzZCQUc3RCxzQkFBTyxFQUFFLFFBQVEsVUFBQSxFQUFFLEVBQUM7Ozs7S0FDckI7SUFFRDs7T0FFRztJQUNLLGlDQUFjLEdBQXRCO1FBQ0UsSUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzNELElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGlCQUFlLE9BQVMsRUFBRSx3QkFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXpELElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFO1lBQ2xDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHlDQUE2QixFQUFFLHdCQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDL0Q7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxnQ0FBYSxHQUFyQixVQUFzQixNQUFjLEVBQUUsSUFBWTtRQUNoRCxJQUFNLFlBQVksR0FBRyxJQUFJLEdBQUcsQ0FBd0I7WUFDbEQsQ0FBQyxZQUFZLEVBQUUsY0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDckMsQ0FBQyxPQUFPLEVBQUUsY0FBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEMsQ0FBQyxlQUFlLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztTQUNoRCxDQUFDLENBQUM7UUFDSCxJQUFJLFFBQVEsR0FBTSxZQUFZLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxTQUFJLFlBQVksQ0FBQyxHQUFHLENBQ2xFLE9BQU8sQ0FDUixTQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFHLENBQUM7UUFFekMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFO1lBQ2pDLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1lBRWpDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FDOUMscUNBQXlCLEVBQ3pCLFVBQUMsUUFBUTtnQkFDUCxJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEVBQUU7b0JBQzlCLDBEQUEwRDtvQkFDMUQsSUFBSSxRQUFRLEtBQUssUUFBUSxFQUFFO3dCQUN6QixZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxTQUFFLEVBQUUsQ0FBQyxDQUFDO3FCQUNsQztvQkFDRCxPQUFPLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFXLENBQUM7aUJBQzdDO3FCQUFNO29CQUNMLE9BQU8sUUFBUSxDQUFDO2lCQUNqQjtZQUNILENBQUMsQ0FDRixDQUFDO1NBQ0g7UUFFRCxPQUFPLEtBQUcsY0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFHLENBQUM7SUFDMUMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssd0NBQXFCLEdBQTdCLFVBQThCLEdBQVc7UUFDdkMsSUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxJQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1FBRS9DLElBQUksaUJBQWlCLElBQUksaUJBQWlCLENBQUMsTUFBTSxFQUFFO1lBQ2pELE9BQU8saUJBQWlCLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3hDO1FBRUQsSUFBSSxpQkFBaUIsSUFBSSxpQkFBaUIsQ0FBQyxNQUFNLEVBQUU7WUFDakQsT0FBTyxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN6QztRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVEOztPQUVHO0lBQ0ssdUNBQW9CLEdBQTVCLFVBQ0UsSUFBWSxFQUNaLFFBQXdCLEVBQ3hCLE1BQXdCO1FBRXhCLElBQU0sT0FBTyxHQUFNLGlCQUFPLENBQUMsWUFBWSxDQUNyQyxRQUFRLENBQUMsVUFBVSxDQUNwQixZQUFPLGlCQUFPLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUcsQ0FBQztRQUNuRCxPQUFPLFFBQVEsQ0FBQyxRQUFRO1lBQ3RCLENBQUMsQ0FBSSxJQUFJLDJDQUFzQyxPQUFPLFVBQUssaUJBQU8sQ0FBQyxjQUFjLENBQzdFLE1BQU0sQ0FDUCxNQUFHO1lBQ04sQ0FBQyxDQUFDLFVBQVEsSUFBSSw2QkFBd0IsT0FBTyxVQUFLLGlCQUFPLENBQUMsY0FBYyxDQUNwRSxNQUFNLENBQ1AsTUFBRyxDQUFDO0lBQ1gsQ0FBQztJQUNILGVBQUM7QUFBRCxDQUFDLEFBelVELElBeVVDO0FBelVZLDRCQUFRIn0=