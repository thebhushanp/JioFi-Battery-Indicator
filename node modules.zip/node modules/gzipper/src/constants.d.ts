export declare const OUTPUT_FILE_FORMAT_REGEXP: RegExp;
export declare const NO_FILES_MESSAGE = "We couldn't find any appropriate files.";
export declare const NO_PATH_MESSAGE = "Can't find a path.";
export declare const INCREMENTAL_ENABLE_MESSAGE = "Incremental compilation has been enabled.";
export declare const DEFAULT_OUTPUT_FORMAT_MESSAGE = "Default output file format: [filename].[ext].[compressExt]";
export declare const CONFIG_FOLDER = ".gzipper";
export declare const CACHE_FOLDER = "cache";
export declare const CONFIG_FILE = ".gzipperconfig";
