"use strict";
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
var __spread = (this && this.__spread) || function () {
    for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.filter = void 0;
var LogLevel_enum_1 = require("./LogLevel.enum");
/**
 * Exec only 'ERROR', 'WARNING', 'SUCCESS' or when 'verbose' flag is available.
 */
function filter() {
    return function (_target, _propertyKey, descriptor) {
        var valueDescriptor = descriptor.value;
        descriptor.value = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var _a = __read(args, 2), level = _a[1];
            var shouldLog = this.verbose ||
                level === LogLevel_enum_1.LogLevel.ERROR ||
                level === LogLevel_enum_1.LogLevel.WARNING ||
                level === LogLevel_enum_1.LogLevel.SUCCESS;
            return shouldLog ? valueDescriptor.call.apply(valueDescriptor, __spread([this], args, [level])) : null;
        };
        return descriptor;
    };
}
exports.filter = filter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsdGVyLmRlY29yYXRvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9sb2dnZXIvZmlsdGVyLmRlY29yYXRvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNBLGlEQUEyQztBQUUzQzs7R0FFRztBQUNILFNBQWdCLE1BQU07SUFLcEIsT0FBTyxVQUFVLE9BQU8sRUFBRSxZQUFZLEVBQUUsVUFBVTtRQUNoRCxJQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO1FBRXpDLFVBQVUsQ0FBQyxLQUFLLEdBQUc7WUFBVSxjQUEyQjtpQkFBM0IsVUFBMkIsRUFBM0IscUJBQTJCLEVBQTNCLElBQTJCO2dCQUEzQix5QkFBMkI7O1lBQ2hELElBQUEsS0FBQSxPQUFZLElBQUksSUFBQSxFQUFiLEtBQUssUUFBUSxDQUFDO1lBQ3ZCLElBQU0sU0FBUyxHQUNaLElBQWUsQ0FBQyxPQUFPO2dCQUN4QixLQUFLLEtBQUssd0JBQVEsQ0FBQyxLQUFLO2dCQUN4QixLQUFLLEtBQUssd0JBQVEsQ0FBQyxPQUFPO2dCQUMxQixLQUFLLEtBQUssd0JBQVEsQ0FBQyxPQUFPLENBQUM7WUFFN0IsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxJQUFJLE9BQXBCLGVBQWUsWUFBTSxJQUFJLEdBQUssSUFBSSxHQUFFLEtBQUssSUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO1FBQ3ZFLENBQUMsQ0FBQztRQUVGLE9BQU8sVUFBVSxDQUFDO0lBQ3BCLENBQUMsQ0FBQztBQUNKLENBQUM7QUFyQkQsd0JBcUJDIn0=