import { LogLevel } from './LogLevel.enum';
/**
 * Custom logger.
 */
export declare class Logger {
    readonly verbose: boolean;
    /**
     * Creates an instance of Logger.
     */
    constructor(verbose: boolean);
    /**
     * Log message.
     */
    log(message: string, level?: LogLevel): void;
    /**
     * Colorize messages depends on the level and return a wrapper.
     */
    private logger;
}
