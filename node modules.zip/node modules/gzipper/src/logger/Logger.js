"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Logger = void 0;
var filter_decorator_1 = require("./filter.decorator");
var LogLevel_enum_1 = require("./LogLevel.enum");
/**
 * Custom logger.
 */
var Logger = /** @class */ (function () {
    /**
     * Creates an instance of Logger.
     */
    function Logger(verbose) {
        this.verbose = verbose;
    }
    /**
     * Log message.
     */
    Logger.prototype.log = function (message, level) {
        if (level === void 0) { level = LogLevel_enum_1.LogLevel.DEBUG; }
        return this.logger(message, level);
    };
    /**
     * Colorize messages depends on the level and return a wrapper.
     */
    Logger.prototype.logger = function (message, level) {
        var colorfulMessage;
        var prefix = 'gzipper';
        switch (level) {
            case LogLevel_enum_1.LogLevel.INFO:
                colorfulMessage = "\u001B[30;46m" + prefix + ":\u001B[0m\u001B[36m %s\u001B[0m";
                break;
            case LogLevel_enum_1.LogLevel.ERROR:
                colorfulMessage = "\u001B[30;41m" + prefix + ":\u001B[0m\u001B[31m %s\u001B[0m";
                break;
            case LogLevel_enum_1.LogLevel.WARNING:
                colorfulMessage = "\u001B[30;43m" + prefix + ":\u001B[0m\u001B[33m %s\u001B[0m";
                break;
            case LogLevel_enum_1.LogLevel.SUCCESS:
                colorfulMessage = "\u001B[30;42m" + prefix + ":\u001B[0m\u001B[32m %s\u001B[0m";
                break;
            case LogLevel_enum_1.LogLevel.DEBUG:
            default:
                colorfulMessage = prefix + ": %s";
                break;
        }
        console.log(colorfulMessage, message);
    };
    __decorate([
        filter_decorator_1.filter()
    ], Logger.prototype, "log", null);
    return Logger;
}());
exports.Logger = Logger;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTG9nZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xvZ2dlci9Mb2dnZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsdURBQTRDO0FBQzVDLGlEQUEyQztBQUUzQzs7R0FFRztBQUNIO0lBRUU7O09BRUc7SUFDSCxnQkFBWSxPQUFnQjtRQUMxQixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztJQUN6QixDQUFDO0lBRUQ7O09BRUc7SUFFSCxvQkFBRyxHQUFILFVBQUksT0FBZSxFQUFFLEtBQWdDO1FBQWhDLHNCQUFBLEVBQUEsUUFBa0Isd0JBQVEsQ0FBQyxLQUFLO1FBQ25ELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVEOztPQUVHO0lBQ0ssdUJBQU0sR0FBZCxVQUFlLE9BQWUsRUFBRSxLQUFlO1FBQzdDLElBQUksZUFBdUIsQ0FBQztRQUM1QixJQUFNLE1BQU0sR0FBRyxTQUFTLENBQUM7UUFFekIsUUFBUSxLQUFLLEVBQUU7WUFDYixLQUFLLHdCQUFRLENBQUMsSUFBSTtnQkFDaEIsZUFBZSxHQUFHLGtCQUFjLE1BQU0scUNBQTRCLENBQUM7Z0JBQ25FLE1BQU07WUFFUixLQUFLLHdCQUFRLENBQUMsS0FBSztnQkFDakIsZUFBZSxHQUFHLGtCQUFjLE1BQU0scUNBQTRCLENBQUM7Z0JBQ25FLE1BQU07WUFFUixLQUFLLHdCQUFRLENBQUMsT0FBTztnQkFDbkIsZUFBZSxHQUFHLGtCQUFjLE1BQU0scUNBQTRCLENBQUM7Z0JBQ25FLE1BQU07WUFFUixLQUFLLHdCQUFRLENBQUMsT0FBTztnQkFDbkIsZUFBZSxHQUFHLGtCQUFjLE1BQU0scUNBQTRCLENBQUM7Z0JBQ25FLE1BQU07WUFFUixLQUFLLHdCQUFRLENBQUMsS0FBSyxDQUFDO1lBQ3BCO2dCQUNFLGVBQWUsR0FBTSxNQUFNLFNBQU0sQ0FBQztnQkFDbEMsTUFBTTtTQUNUO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQW5DRDtRQURDLHlCQUFNLEVBQUU7cUNBR1I7SUFrQ0gsYUFBQztDQUFBLEFBakRELElBaURDO0FBakRZLHdCQUFNIn0=