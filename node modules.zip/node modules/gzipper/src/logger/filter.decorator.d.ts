/**
 * Exec only 'ERROR', 'WARNING', 'SUCCESS' or when 'verbose' flag is available.
 */
export declare function filter(): (target: unknown, propertyKey: string, descriptor: PropertyDescriptor) => void;
