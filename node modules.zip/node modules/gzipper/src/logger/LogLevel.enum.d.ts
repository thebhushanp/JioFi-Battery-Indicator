export declare enum LogLevel {
    INFO = 0,
    ERROR = 1,
    SUCCESS = 2,
    WARNING = 3,
    DEBUG = 4
}
