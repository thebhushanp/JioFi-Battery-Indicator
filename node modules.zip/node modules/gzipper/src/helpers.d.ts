export declare class Helpers {
    private static readonly nativeFs;
    /**
     * Create folders by path.
     */
    static createFolders(target: string): Promise<void>;
    /**
     * Convert Map to JSON.
     */
    static mapToJSON<K extends string, V>(map: Map<K, V>): Record<K, V>;
    /**
     * Returns package version.
     */
    static getVersion(): string;
    /**
     * Converts a long string of bytes into a readable format e.g KB, MB, GB, TB, YB
     */
    static readableSize(bytes: number): string;
    /**
     * returns readable format from hrtime.
     */
    static readableHrtime(hrTime: [number, number]): string;
    /**
     * Read file via readable stream.
     */
    static readFile(file: string): Promise<string>;
}
