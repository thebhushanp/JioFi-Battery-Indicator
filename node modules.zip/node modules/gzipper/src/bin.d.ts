export declare class Index {
    private readonly argv;
    private readonly env;
    private commander;
    exec(): Promise<void>;
    private compress;
    private cachePurge;
    private cacheSize;
    private runCompress;
    private filterOptions;
    private optionToArray;
}
