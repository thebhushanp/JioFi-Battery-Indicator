/// <reference types="node" />
import zlib from 'zlib';
import { CompressOptions, CompressionOptions } from '../interfaces';
import { Logger } from '../logger/Logger';
export declare abstract class Compression<T extends CompressionOptions> {
    compressionOptions: T;
    abstract ext: string;
    abstract compressionName: string;
    protected readonly options: CompressOptions;
    protected readonly logger: Logger;
    /**
     * Creates an instance of Compression.
     */
    constructor(options: CompressOptions, logger: Logger);
    /**
     * Returns a compression instance in closure.
     */
    abstract getCompression(): () => zlib.BrotliCompress | zlib.Gzip;
    /**
     * Returns human-readable compression options info.
     */
    readableOptions(keyWrapper?: (key: string) => string | undefined): string;
    /**
     * Build compression options object [compressionOptions].
     */
    protected selectCompression(): void;
}
