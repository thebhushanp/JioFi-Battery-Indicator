/// <reference types="node" />
import zlib from 'zlib';
import { Compression } from './Compression';
import { CompressOptions, CompressionOptions } from '../interfaces';
import { Logger } from '../logger/Logger';
/**
 * Deflate compression
 */
export declare class DeflateCompression extends Compression<CompressionOptions> {
    readonly compressionName = "DEFLATE";
    readonly ext = "zz";
    /**
     * Creates an instance of GzipCompression.
     */
    constructor(options: CompressOptions, logger: Logger);
    /**
     * Returns deflate compression instance in closure.
     */
    getCompression(): () => zlib.Deflate;
}
