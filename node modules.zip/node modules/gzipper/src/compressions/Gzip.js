"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GzipCompression = void 0;
var zlib_1 = __importDefault(require("zlib"));
var Compression_1 = require("./Compression");
/**
 * Gzip compression
 */
var GzipCompression = /** @class */ (function (_super) {
    __extends(GzipCompression, _super);
    /**
     * Creates an instance of GzipCompression.
     */
    function GzipCompression(options, logger) {
        var _this = _super.call(this, options, logger) || this;
        _this.compressionName = 'GZIP';
        _this.ext = 'gz';
        return _this;
    }
    /**
     * Returns gzip compression instance in closure.
     */
    GzipCompression.prototype.getCompression = function () {
        var _this = this;
        return function () { return zlib_1.default.createGzip(_this.compressionOptions); };
    };
    return GzipCompression;
}(Compression_1.Compression));
exports.GzipCompression = GzipCompression;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiR3ppcC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wcmVzc2lvbnMvR3ppcC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOENBQXdCO0FBRXhCLDZDQUE0QztBQUk1Qzs7R0FFRztBQUNIO0lBQXFDLG1DQUErQjtJQUdsRTs7T0FFRztJQUNILHlCQUFZLE9BQXdCLEVBQUUsTUFBYztRQUFwRCxZQUNFLGtCQUFNLE9BQU8sRUFBRSxNQUFNLENBQUMsU0FDdkI7UUFQUSxxQkFBZSxHQUFHLE1BQU0sQ0FBQztRQUN6QixTQUFHLEdBQUcsSUFBSSxDQUFDOztJQU1wQixDQUFDO0lBRUQ7O09BRUc7SUFDSCx3Q0FBYyxHQUFkO1FBQUEsaUJBRUM7UUFEQyxPQUFPLGNBQWlCLE9BQUEsY0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBeEMsQ0FBd0MsQ0FBQztJQUNuRSxDQUFDO0lBQ0gsc0JBQUM7QUFBRCxDQUFDLEFBaEJELENBQXFDLHlCQUFXLEdBZ0IvQztBQWhCWSwwQ0FBZSJ9