/// <reference types="node" />
import zlib from 'zlib';
import { Compression } from './Compression';
import { CompressOptions, CompressionOptions } from '../interfaces';
import { Logger } from '../logger/Logger';
/**
 * Gzip compression
 */
export declare class GzipCompression extends Compression<CompressionOptions> {
    readonly compressionName = "GZIP";
    readonly ext = "gz";
    /**
     * Creates an instance of GzipCompression.
     */
    constructor(options: CompressOptions, logger: Logger);
    /**
     * Returns gzip compression instance in closure.
     */
    getCompression(): () => zlib.Gzip;
}
