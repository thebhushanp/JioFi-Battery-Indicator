"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BrotliCompression = void 0;
var zlib_1 = __importDefault(require("zlib"));
var Compression_1 = require("./Compression");
var LogLevel_enum_1 = require("../logger/LogLevel.enum");
/**
 * Brotli compression
 */
var BrotliCompression = /** @class */ (function (_super) {
    __extends(BrotliCompression, _super);
    /**
     * Creates an instance of BrotliCompression
     */
    function BrotliCompression(options, logger) {
        var _this = _super.call(this, options, logger) || this;
        _this.compressionName = 'BROTLI';
        _this.ext = 'br';
        _this.availability();
        return _this;
    }
    /**
     * Returns brotli compression instance in closure.
     */
    BrotliCompression.prototype.getCompression = function () {
        var _this = this;
        return function () {
            return zlib_1.default.createBrotliCompress({
                params: _this.compressionOptions,
            });
        };
    };
    /**
     * Returns human-readable brotli compression options info.
     */
    BrotliCompression.prototype.readableOptions = function () {
        return _super.prototype.readableOptions.call(this, this.getBrotliOptionName.bind(this));
    };
    /**
     * Build brotli options object [compressionOptions].
     */
    BrotliCompression.prototype.selectCompression = function () {
        var options = {};
        if (this.options.brotliParamMode !== undefined) {
            switch (this.options.brotliParamMode) {
                case 'text':
                    options[zlib_1.default.constants.BROTLI_PARAM_MODE] =
                        zlib_1.default.constants.BROTLI_MODE_TEXT;
                    break;
                case 'font':
                    options[zlib_1.default.constants.BROTLI_PARAM_MODE] =
                        zlib_1.default.constants.BROTLI_MODE_FONT;
                    break;
                case 'default':
                default:
                    options[zlib_1.default.constants.BROTLI_PARAM_MODE] =
                        zlib_1.default.constants.BROTLI_MODE_GENERIC;
                    break;
            }
        }
        if (this.options.brotliQuality !== undefined) {
            options[zlib_1.default.constants.BROTLI_PARAM_QUALITY] = this.options.brotliQuality;
        }
        if (this.options.brotliSizeHint !== undefined) {
            options[zlib_1.default.constants.BROTLI_PARAM_SIZE_HINT] = this.options.brotliSizeHint;
        }
        this.compressionOptions = options;
    };
    /**
     * Returns human-readable brotli option name.
     */
    BrotliCompression.prototype.getBrotliOptionName = function (index) {
        switch (parseInt(index)) {
            case zlib_1.default.constants.BROTLI_PARAM_MODE:
                return 'brotliParamMode';
            case zlib_1.default.constants.BROTLI_PARAM_QUALITY:
                return 'brotliQuality';
            case zlib_1.default.constants.BROTLI_PARAM_SIZE_HINT:
                return 'brotliSizeHint';
        }
    };
    /**
     * Check if brotli compression is exists on current Node.js version.
     */
    BrotliCompression.prototype.availability = function () {
        if (typeof zlib_1.default.createBrotliCompress !== 'function') {
            var message = "Can't use brotli compression, Node.js >= v11.7.0 required.";
            this.logger.log(message, LogLevel_enum_1.LogLevel.ERROR);
            throw new Error(message);
        }
    };
    return BrotliCompression;
}(Compression_1.Compression));
exports.BrotliCompression = BrotliCompression;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQnJvdGxpLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2NvbXByZXNzaW9ucy9Ccm90bGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDhDQUF3QjtBQUV4Qiw2Q0FBNEM7QUFHNUMseURBQW1EO0FBRW5EOztHQUVHO0FBQ0g7SUFBdUMscUNBQTBCO0lBRy9EOztPQUVHO0lBQ0gsMkJBQVksT0FBd0IsRUFBRSxNQUFjO1FBQXBELFlBQ0Usa0JBQU0sT0FBTyxFQUFFLE1BQU0sQ0FBQyxTQUV2QjtRQVJRLHFCQUFlLEdBQUcsUUFBUSxDQUFDO1FBQzNCLFNBQUcsR0FBRyxJQUFJLENBQUM7UUFNbEIsS0FBSSxDQUFDLFlBQVksRUFBRSxDQUFDOztJQUN0QixDQUFDO0lBRUQ7O09BRUc7SUFDSCwwQ0FBYyxHQUFkO1FBQUEsaUJBS0M7UUFKQyxPQUFPO1lBQ0wsT0FBQSxjQUFJLENBQUMsb0JBQW9CLENBQUM7Z0JBQ3hCLE1BQU0sRUFBRSxLQUFJLENBQUMsa0JBQWtCO2FBQ2hDLENBQUM7UUFGRixDQUVFLENBQUM7SUFDUCxDQUFDO0lBRUQ7O09BRUc7SUFDSCwyQ0FBZSxHQUFmO1FBQ0UsT0FBTyxpQkFBTSxlQUFlLFlBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFFRDs7T0FFRztJQUNPLDZDQUFpQixHQUEzQjtRQUNFLElBQU0sT0FBTyxHQUFrQixFQUFFLENBQUM7UUFFbEMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsS0FBSyxTQUFTLEVBQUU7WUFDOUMsUUFBUSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRTtnQkFDcEMsS0FBSyxNQUFNO29CQUNULE9BQU8sQ0FBQyxjQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDO3dCQUN2QyxjQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDO29CQUNsQyxNQUFNO2dCQUVSLEtBQUssTUFBTTtvQkFDVCxPQUFPLENBQUMsY0FBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDdkMsY0FBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQztvQkFDbEMsTUFBTTtnQkFFUixLQUFLLFNBQVMsQ0FBQztnQkFDZjtvQkFDRSxPQUFPLENBQUMsY0FBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQzt3QkFDdkMsY0FBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsQ0FBQztvQkFDckMsTUFBTTthQUNUO1NBQ0Y7UUFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxLQUFLLFNBQVMsRUFBRTtZQUM1QyxPQUFPLENBQUMsY0FBSSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO1NBQzNFO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsS0FBSyxTQUFTLEVBQUU7WUFDN0MsT0FBTyxDQUNMLGNBQUksQ0FBQyxTQUFTLENBQUMsc0JBQXNCLENBQ3RDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUM7U0FDakM7UUFDRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDO0lBQ3BDLENBQUM7SUFFRDs7T0FFRztJQUNPLCtDQUFtQixHQUE3QixVQUE4QixLQUFhO1FBQ3pDLFFBQVEsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3ZCLEtBQUssY0FBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUI7Z0JBQ25DLE9BQU8saUJBQWlCLENBQUM7WUFFM0IsS0FBSyxjQUFJLENBQUMsU0FBUyxDQUFDLG9CQUFvQjtnQkFDdEMsT0FBTyxlQUFlLENBQUM7WUFFekIsS0FBSyxjQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQjtnQkFDeEMsT0FBTyxnQkFBZ0IsQ0FBQztTQUMzQjtJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLHdDQUFZLEdBQXBCO1FBQ0UsSUFBSSxPQUFPLGNBQUksQ0FBQyxvQkFBb0IsS0FBSyxVQUFVLEVBQUU7WUFDbkQsSUFBTSxPQUFPLEdBQUcsNERBQTRELENBQUM7WUFDN0UsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLHdCQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDekMsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMxQjtJQUNILENBQUM7SUFDSCx3QkFBQztBQUFELENBQUMsQUE1RkQsQ0FBdUMseUJBQVcsR0E0RmpEO0FBNUZZLDhDQUFpQiJ9