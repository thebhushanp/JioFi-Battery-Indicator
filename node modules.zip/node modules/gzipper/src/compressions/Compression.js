"use strict";
var __values = (this && this.__values) || function(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
};
var __read = (this && this.__read) || function (o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Compression = void 0;
var Compression = /** @class */ (function () {
    /**
     * Creates an instance of Compression.
     */
    function Compression(options, logger) {
        this.compressionOptions = {};
        this.options = options;
        this.logger = logger;
        this.selectCompression();
    }
    /**
     * Returns human-readable compression options info.
     */
    Compression.prototype.readableOptions = function (keyWrapper) {
        var e_1, _a;
        if (keyWrapper === void 0) { keyWrapper = function (key) { return key; }; }
        var options = '';
        try {
            for (var _b = __values(Object.entries(this.compressionOptions)), _c = _b.next(); !_c.done; _c = _b.next()) {
                var _d = __read(_c.value, 2), key = _d[0], value = _d[1];
                options += keyWrapper(key) + ": " + value + ", ";
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return this.compressionName + " | " + options.slice(0, -2);
    };
    /**
     * Build compression options object [compressionOptions].
     */
    Compression.prototype.selectCompression = function () {
        var options = {};
        if (this.options.level !== undefined) {
            options.level = this.options.level;
        }
        if (this.options.memoryLevel !== undefined) {
            options.memLevel = this.options.memoryLevel;
        }
        if (this.options.strategy !== undefined) {
            options.strategy = this.options.strategy;
        }
        this.compressionOptions = options;
    };
    return Compression;
}());
exports.Compression = Compression;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcHJlc3Npb24uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29tcHJlc3Npb25zL0NvbXByZXNzaW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUtBO0lBT0U7O09BRUc7SUFDSCxxQkFBWSxPQUF3QixFQUFFLE1BQWM7UUFUcEQsdUJBQWtCLEdBQU0sRUFBTyxDQUFDO1FBVTlCLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFPRDs7T0FFRztJQUNILHFDQUFlLEdBQWYsVUFDRSxVQUU0Qjs7UUFGNUIsMkJBQUEsRUFBQSx1QkFDRSxHQUFXLElBQ1ksT0FBQSxHQUFHLEVBQUgsQ0FBRztRQUU1QixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7O1lBRWpCLEtBQTJCLElBQUEsS0FBQSxTQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUEsZ0JBQUEsNEJBQUU7Z0JBQXpELElBQUEsS0FBQSxtQkFBWSxFQUFYLEdBQUcsUUFBQSxFQUFFLEtBQUssUUFBQTtnQkFDcEIsT0FBTyxJQUFPLFVBQVUsQ0FBQyxHQUFHLENBQUMsVUFBSyxLQUFLLE9BQUksQ0FBQzthQUM3Qzs7Ozs7Ozs7O1FBRUQsT0FBVSxJQUFJLENBQUMsZUFBZSxXQUFNLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFHLENBQUM7SUFDN0QsQ0FBQztJQUVEOztPQUVHO0lBQ08sdUNBQWlCLEdBQTNCO1FBQ0UsSUFBTSxPQUFPLEdBQU0sRUFBTyxDQUFDO1FBRTNCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEtBQUssU0FBUyxFQUFFO1lBQ3BDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7U0FDcEM7UUFFRCxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRTtZQUMxQyxPQUFPLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO1NBQzdDO1FBRUQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDdkMsT0FBTyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztTQUMxQztRQUVELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxPQUFPLENBQUM7SUFDcEMsQ0FBQztJQUNILGtCQUFDO0FBQUQsQ0FBQyxBQTFERCxJQTBEQztBQTFEcUIsa0NBQVcifQ==