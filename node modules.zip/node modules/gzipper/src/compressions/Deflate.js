"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeflateCompression = void 0;
var zlib_1 = __importDefault(require("zlib"));
var Compression_1 = require("./Compression");
/**
 * Deflate compression
 */
var DeflateCompression = /** @class */ (function (_super) {
    __extends(DeflateCompression, _super);
    /**
     * Creates an instance of GzipCompression.
     */
    function DeflateCompression(options, logger) {
        var _this = _super.call(this, options, logger) || this;
        _this.compressionName = 'DEFLATE';
        _this.ext = 'zz';
        return _this;
    }
    /**
     * Returns deflate compression instance in closure.
     */
    DeflateCompression.prototype.getCompression = function () {
        var _this = this;
        return function () { return zlib_1.default.createDeflate(_this.compressionOptions); };
    };
    return DeflateCompression;
}(Compression_1.Compression));
exports.DeflateCompression = DeflateCompression;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGVmbGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb21wcmVzc2lvbnMvRGVmbGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsOENBQXdCO0FBRXhCLDZDQUE0QztBQUk1Qzs7R0FFRztBQUNIO0lBQXdDLHNDQUErQjtJQUdyRTs7T0FFRztJQUNILDRCQUFZLE9BQXdCLEVBQUUsTUFBYztRQUFwRCxZQUNFLGtCQUFNLE9BQU8sRUFBRSxNQUFNLENBQUMsU0FDdkI7UUFQUSxxQkFBZSxHQUFHLFNBQVMsQ0FBQztRQUM1QixTQUFHLEdBQUcsSUFBSSxDQUFDOztJQU1wQixDQUFDO0lBRUQ7O09BRUc7SUFDSCwyQ0FBYyxHQUFkO1FBQUEsaUJBRUM7UUFEQyxPQUFPLGNBQW9CLE9BQUEsY0FBSSxDQUFDLGFBQWEsQ0FBQyxLQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBM0MsQ0FBMkMsQ0FBQztJQUN6RSxDQUFDO0lBQ0gseUJBQUM7QUFBRCxDQUFDLEFBaEJELENBQXdDLHlCQUFXLEdBZ0JsRDtBQWhCWSxnREFBa0IifQ==