/// <reference types="node" />
import zlib from 'zlib';
import { Compression } from './Compression';
import { Logger } from '../logger/Logger';
import { CompressOptions, BrotliOptions } from '../interfaces';
/**
 * Brotli compression
 */
export declare class BrotliCompression extends Compression<BrotliOptions> {
    readonly compressionName = "BROTLI";
    readonly ext = "br";
    /**
     * Creates an instance of BrotliCompression
     */
    constructor(options: CompressOptions, logger: Logger);
    /**
     * Returns brotli compression instance in closure.
     */
    getCompression(): () => zlib.BrotliCompress;
    /**
     * Returns human-readable brotli compression options info.
     */
    readableOptions(): string;
    /**
     * Build brotli options object [compressionOptions].
     */
    protected selectCompression(): void;
    /**
     * Returns human-readable brotli option name.
     */
    protected getBrotliOptionName(index: string): string | undefined;
    /**
     * Check if brotli compression is exists on current Node.js version.
     */
    private availability;
}
