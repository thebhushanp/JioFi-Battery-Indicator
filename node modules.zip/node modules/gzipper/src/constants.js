"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONFIG_FILE = exports.CACHE_FOLDER = exports.CONFIG_FOLDER = exports.DEFAULT_OUTPUT_FORMAT_MESSAGE = exports.INCREMENTAL_ENABLE_MESSAGE = exports.NO_PATH_MESSAGE = exports.NO_FILES_MESSAGE = exports.OUTPUT_FILE_FORMAT_REGEXP = void 0;
exports.OUTPUT_FILE_FORMAT_REGEXP = /(\[filename\]*)|(\[hash\]*)|(\[compressExt\]*)|(\[ext\]*)/g;
exports.NO_FILES_MESSAGE = "We couldn't find any appropriate files.";
exports.NO_PATH_MESSAGE = "Can't find a path.";
exports.INCREMENTAL_ENABLE_MESSAGE = 'Incremental compilation has been enabled.';
exports.DEFAULT_OUTPUT_FORMAT_MESSAGE = 'Default output file format: [filename].[ext].[compressExt]';
exports.CONFIG_FOLDER = '.gzipper';
exports.CACHE_FOLDER = 'cache';
exports.CONFIG_FILE = '.gzipperconfig';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uc3RhbnRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NvbnN0YW50cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBYSxRQUFBLHlCQUF5QixHQUFHLDREQUE0RCxDQUFDO0FBQ3pGLFFBQUEsZ0JBQWdCLEdBQUcseUNBQXlDLENBQUM7QUFDN0QsUUFBQSxlQUFlLEdBQUcsb0JBQW9CLENBQUM7QUFDdkMsUUFBQSwwQkFBMEIsR0FDckMsMkNBQTJDLENBQUM7QUFDakMsUUFBQSw2QkFBNkIsR0FDeEMsNERBQTRELENBQUM7QUFDbEQsUUFBQSxhQUFhLEdBQUcsVUFBVSxDQUFDO0FBQzNCLFFBQUEsWUFBWSxHQUFHLE9BQU8sQ0FBQztBQUN2QixRQUFBLFdBQVcsR0FBRyxnQkFBZ0IsQ0FBQyJ9