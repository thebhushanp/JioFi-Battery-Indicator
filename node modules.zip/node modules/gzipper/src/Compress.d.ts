import { CompressOptions } from './interfaces';
/**
 * Compressing files.
 */
export declare class Compress {
    private readonly nativeFs;
    private readonly nativeStream;
    private readonly logger;
    private readonly incremental;
    private readonly config;
    private readonly options;
    private readonly outputPath;
    private readonly compressionInstance;
    private readonly target;
    private readonly createCompression;
    /**
     * Creates an instance of Compress.
     */
    constructor(target: string, outputPath?: string | null, options?: CompressOptions);
    /**
     * Start compressing files.
     */
    run(): Promise<string[]>;
    /**
     * Return compression instance.
     */
    private getCompressionInstance;
    /**
     * Compile files in folder recursively.
     */
    private compileFolderRecursively;
    /**
     * File compression.
     */
    private compressFile;
    /**
     * Show message with compression params.
     */
    private compressionLog;
    /**
     * Get output path which is based on [outputFileFormat].
     */
    private getOutputPath;
    /**
     * Returns if the file extension is valid.
     */
    private isValidFileExtensions;
    /**
     * Returns information message about compressed file (size, time, cache, etc.)
     */
    private getCompressedFileMsg;
}
