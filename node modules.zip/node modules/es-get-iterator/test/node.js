'use strict';

require('./');
