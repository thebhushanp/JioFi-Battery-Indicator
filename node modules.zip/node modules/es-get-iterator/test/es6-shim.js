'use strict';

if (process.env.PRELOAD_GET_ITERATOR) {
	// eslint-disable-next-line global-require
	require('../');
}

require('es5-shim');
require('es6-shim');

require('./');
